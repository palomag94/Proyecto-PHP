@extends ('plantilla')

@section('seccion')

<h3>Nuevo Asignatura</h3>

<hr />

@if(session('mensaje'))
    <div class="alert alert-success">
        {{session('mensaje')}}
</div>
@endif

<form method="POST" action="{{route('crearasignatura')}}">
@csrf
  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="nombre">Nombre</label>
      <input type="text" class="form-control" id="nombre" name="nombre" placeholder="Nombre" required>
    </div>
 </div>
  <!--<div class="form-group">
    <div class="form-check">
      <input class="form-check-input" type="checkbox" id="gridCheck">
      <label class="form-check-label" for="gridCheck">
        Check me out
      </label>
    </div>
  </div>-->
  <button type="submit" class="btn btn-primary">Añadir</button> <a class="btn btn-primary" href="{{route('asignatura')}}">Volver</a>
</form>

@endsection