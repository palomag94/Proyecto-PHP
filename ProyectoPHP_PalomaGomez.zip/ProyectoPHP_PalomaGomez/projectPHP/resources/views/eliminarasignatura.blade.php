@extends('plantilla')

@section('seccion')

<h3>Eliminación del Alumno</h3>

<form  action="{{ route('eliminarasignatura','$id')}}" class="d-inline" method="POST">
        @method('DELETE')
        @csrf
        <div>
            <p>¿Desea eliminar la asignatura?</p>
        </div>
        <div >
             <button type="submit" class="btn btn-primary">Aceptar</button>
             <a class="btn btn-primary " href="{{ route ('asignatura')}}" role="button">Cancelar</a>
        </div>
    </form>

@endsection