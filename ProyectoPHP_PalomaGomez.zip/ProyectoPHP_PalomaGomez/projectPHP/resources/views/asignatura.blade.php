@extends('plantilla')

@section('seccion')

<h3>Datos de las asignaturas</h3>

<br>

<table class="table">
  <thead class="thead-dark">
    <tr>
      <th scope="col">ID</th>
      <th scope="col">Nombre Asignatura</th>
      <th scope="col">Acciones</th>
    </tr>
  </thead>

  <tbody>
    <tr>
    @foreach($asignatura as $item)
      <th scope="row">{{ $item->id}}</th>
      <td>{{ $item->nombre}}</td>
      <td> 
            <a  href="{{route('editarasignatura',$item)}}" >Editar</a>        

            <a  href="{{route('eliminarasignatura',$item)}}" >Eliminar</a>

        </td>
    </tr>
    @endforeach()
  </tbody>
</table>

<p><a class="btn btn-primary " href="{{ route ('crearasignatura')}}" role="button">Crear Asignatura</a>  <a class="btn btn-primary" href='/'>Volver</a></p>

@endsection