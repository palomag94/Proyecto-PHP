@extends('plantilla')

@section('seccion')

<h3>Datos de las notas</h3>

<br>

<table class="table">
  <thead class="thead-dark">
    <tr>
      <th scope="col">ID</th>
      <th scope="col">Nombre Asignatura</th>
      <th scope="col">Nombre Alumno</th>
      <th scope="col">Valor</th>
    </tr>
  </thead>

  <tbody>
    <tr>
    @foreach($nota as $item)
      <th scope="row">{{ $item->id}}</th>
      <td>{{ $item->nombreAsignatura}}</td>
      <td>{{ $item->nombreAlumno}}</td>
      <td>{{ $item->valor}}</td>
    </tr>
    @endforeach()
  </tbody>
</table>

<p><a class="btn btn-primary " href="{{ route ('crearnota')}}" role="button">Añadir Nota</a> <a class="btn btn-primary" href='/'>Volver</a></p>

@endsection