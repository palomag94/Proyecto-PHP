@extends('plantilla')

@section('seccion')
<p><a class="btn btn-primary " href="resumenNotas" role="button">Resumen</a></p>

<table class="table">
  <thead class="thead-dark">
    <tr>
      <th scope="col" class="text-center">Nombre Alumno</th>
      <th scope="col" class="text-center">Apellidos Alumno</th>
      <th scope="col" class="text-center">Asignatura</th>
      <th scope="col" class="text-center">Nota Media</th>
    </tr>
  </thead>

  <tbody>
    <tr>

    @foreach($notas as $n)
    <tr>
      <td scope="row" class="text-center"> {{$n->nombre}} </td>
      <td scope="row" class="text-center"> {{$n->Apellidos}} </td>
      <td scope="row" class="text-center"> {{$n->asignatura}} </td>
      <td scope="row" class="text-center"> {{$n->Nota}} </td>
</tr>
    @endforeach


    </tr>
  </tbody>
</table>

@endsection