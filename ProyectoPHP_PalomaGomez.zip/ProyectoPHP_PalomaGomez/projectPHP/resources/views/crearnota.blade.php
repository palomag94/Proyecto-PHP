@extends ('plantilla')

@section('seccion')

<h3>Insertar Nota</h3>

<hr />

@if(session('mensaje'))
    <div class="alert alert-success">
        {{session('mensaje')}}
</div>
@endif

<form method="POST" action="{{route('crearnota')}}">
@csrf
  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="nombreAsignatura">Nombre Asignatura</label>
      <input type="text" class="form-control" id="nombreAsignatura" name="nombreAsignatura" placeholder="Nombre Asignatura" required>
    </div>
    <div class="form-group col-md-6">
      <label for="nombreAlumno">Nombre Alumno</label>
      <input type="text" class="form-control" id="nombreAlumno" name="nombreAlumno" placeholder="Nombre Alumno" required>
    </div>
    <div class="form-group col-md-6">
      <label for="valor">Valor</label>
      <input type="integer" class="form-control" id="valor" name="valor" placeholder="Valor" required>
    </div>
 </div>

  <button type="submit" class="btn btn-primary">Insertar</button> <a class="btn btn-primary" href="{{route('nota')}}">Volver</a>
</form>

@endsection