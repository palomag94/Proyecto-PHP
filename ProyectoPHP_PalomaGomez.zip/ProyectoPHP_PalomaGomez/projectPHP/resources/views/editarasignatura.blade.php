@extends ('plantilla')

@section('seccion')

<h3>Editar Asignatura</h3>

<hr />

<form  action="{{route('editarasignatura', $asignatura->id)}}" method="POST"  class="d-inline">
@method('PUT')
@csrf

  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="nombre">Nombre</label>
      <input type="text" class="form-control" id="nombre" name="nombre" placeholder="Nombre" value="{{ $asignatura->nombre}}">
    </div>
 </div>
 <div>
    <button type="submit" class="btn btn-primary">Guardar Cambios</button> 
    <a class="btn btn-primary" href="{{route('asignatura')}}">Volver</a>
</div>
</form>

@endsection