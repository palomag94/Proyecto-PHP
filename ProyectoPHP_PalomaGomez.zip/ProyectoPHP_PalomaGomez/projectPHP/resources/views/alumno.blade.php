@extends('plantilla')

@section('seccion')

<form action="{{ route('buscaralumno')}}" class="form-inline my-2 my-lg-0">
  
      <input class="form-control mr-sm-2" type="text" name="nombre" placeholder="Nombre del alumno" aria-label="Buscar">
      <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Buscar</button>
</form>


<br>

<h3>Datos de los alumnos</h3>

<br>

<table class="table">
  <thead class="thead-dark">
    <tr>
      <th scope="col">ID</th>
      <th scope="col">Nombre</th>
      <th scope="col">Apellidos</th>
      <th scope="col">DNI</th>
      <th scope="col">Direccion</th>
      <th scope="col">Email</th>
      <th scope="col">Fecha Nacimiento</th>
      <th scope="col">Poblacion</th>
      <th scope="col">Provincia</th>
      <th scope="col">Teléfono/s</th>
      <th scope="col">Acciones</th>
    </tr>
  </thead>

  <tbody>
      @foreach($alumno as $item)
        <tr>
        <th scope="row">{{ $item->id}}</th>
        <td>{{ $item->nombre}}</td>
        <td>{{ $item->apellidos}}</td>
        <td>{{ $item->DNI}}</td>
        <td>{{ $item->direccion}}</td>
        <td>{{ $item->email}}</td>
        <td>{{ $item->fechaNacimiento}}</td>
        <td>{{ $item->poblacion}}</td>
        <td>{{ $item->provincia}}</td>
        <td>{{ $item->Telefono}}</td>

        <td> 
            <a  href="{{route('editaralumno',$item)}}" >Editar</a>        

            <a  href="{{route('eliminaralumno',$item)}}" >Eliminar</a>

        </td>
        </tr>
    @endforeach()
  </tbody>
</table>

<p> <a class="btn btn-primary " href="{{ route ('crearalumno')}}" role="button">Crear Alumno</a>  <a class="btn btn-primary" href='/'>Volver</a></p>

@endsection