@extends('plantilla')

@section('seccion')

<h3>Eliminación del Alumno</h3>

<form  action="{{ route('eliminaralumno','$id')}}" class="d-inline" method="POST">
        @method('DELETE')
        @csrf
        <div>
            <p>¿Desea eliminar el alumno?</p>
        </div>
        <div >
             <button type="submit" class="btn btn-primary">Aceptar</button>
             <a class="btn btn-primary " href="{{ route ('alumno')}}" role="button">Cancelar</a>
        </div>
    </form>

@endsection