<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//INICIO

Route::get('/', 'PageController@inicio')->name('home');

Route::get('/resumenNotas', 'PageController@resumenNotas')->name('resumenNotas');


//ALUMNOS

Route::get('alumno','PageController@alumno')->name('alumno');


Route::get('crearalumno','PageController@ShowViewCrearAlumno')->name('crearalumno');

Route::post('crearalumno','PageController@crearalumno')->name('crearalumno');



Route::get('/editaralumno/{id}','PageController@ShowVieweditaralumno')->name('editaralumno');

Route::put('/editaralumno/{id}','PageController@editaralumno')->name('editaralumno');



Route::get('/eliminaralumno/{id}','PageController@eliminaralumno')->name('eliminaralumno');


Route::get('/buscaralumno','PageController@buscaralumno')->name('buscaralumno');


//ASIGNATURAS

Route::get('asignatura', 'PageController@asignatura')->name('asignatura');


Route::get('crearasignatura','PageController@ShowViewCrearAsignatura')->name('crearasignatura');

Route::post('crearasignatura', 'PageController@crearasignatura')->name('crearasignatura');



Route::get('/editarasignatura/{id}','PageController@ShowVieweditarasignatura')->name('editarasignatura');

Route::put('/editarasignatura/{id}','PageController@editarasignatura')->name('editarasignatura');



Route::get('/eliminarasignatura/{id}','PageController@eliminarasignatura')->name('eliminarasignatura');


//NOTAS

Route::get('nota', 'PageController@nota')->name('nota');

Route::get('crearnota','PageController@ShowViewCrearNota')->name('crearnota');

Route::post('crearnota', 'PageController@crearnota')->name('crearnota');


