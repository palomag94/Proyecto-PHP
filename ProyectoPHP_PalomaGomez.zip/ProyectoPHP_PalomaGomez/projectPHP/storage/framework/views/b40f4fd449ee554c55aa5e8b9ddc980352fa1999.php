<?php $__env->startSection('seccion'); ?>

<h3>Datos de las notas</h3>

<br>

<table class="table">
  <thead class="thead-dark">
    <tr>
      <th scope="col">ID</th>
      <th scope="col">Nombre Asignatura</th>
      <th scope="col">Nombre Alumno</th>
      <th scope="col">Valor</th>
    </tr>
  </thead>

  <tbody>
    <tr>
    <?php $__currentLoopData = $nota; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <th scope="row"><?php echo e($item->id); ?></th>
      <td><?php echo e($item->nombreAsignatura); ?></td>
      <td><?php echo e($item->nombreAlumno); ?></td>
      <td><?php echo e($item->valor); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>

<p><a class="btn btn-primary " href="<?php echo e(route ('crearnota')); ?>" role="button">Añadir Nota</a> <a class="btn btn-primary" href='/'>Volver</a></p>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projectPHP\resources\views/nota.blade.php ENDPATH**/ ?>