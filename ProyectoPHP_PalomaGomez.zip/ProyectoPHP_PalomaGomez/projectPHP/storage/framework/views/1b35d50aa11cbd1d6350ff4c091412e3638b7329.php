<?php $__env->startSection('seccion'); ?>
<p><a class="btn btn-primary " href="resumenNotas" role="button">Resumen</a></p>

<table class="table">
  <thead class="thead-dark">
    <tr>
      <th scope="col" class="text-center">Nombre Alumno</th>
      <th scope="col" class="text-center">Apellidos Alumno</th>
      <th scope="col" class="text-center">Asignatura</th>
      <th scope="col" class="text-center">Nota Media</th>
    </tr>
  </thead>

  <tbody>
    <tr>

    <?php $__currentLoopData = $notas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td scope="row" class="text-center"> <?php echo e($n->nombre); ?> </td>
      <td scope="row" class="text-center"> <?php echo e($n->Apellidos); ?> </td>
      <td scope="row" class="text-center"> <?php echo e($n->asignatura); ?> </td>
      <td scope="row" class="text-center"> <?php echo e($n->Nota); ?> </td>
</tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    </tr>
  </tbody>
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projectPHP\resources\views/home.blade.php ENDPATH**/ ?>