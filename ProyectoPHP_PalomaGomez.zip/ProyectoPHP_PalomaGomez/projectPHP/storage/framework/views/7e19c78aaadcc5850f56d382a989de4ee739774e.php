<?php $__env->startSection('seccion'); ?>

<h3>Editar Asignatura</h3>

<hr />

<form  action="<?php echo e(route('editarasignatura', $asignatura->id)); ?>" method="POST"  class="d-inline">
<?php echo method_field('PUT'); ?>
<?php echo csrf_field(); ?>

  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="nombre">Nombre</label>
      <input type="text" class="form-control" id="nombre" name="nombre" placeholder="Nombre" value="<?php echo e($asignatura->nombre); ?>">
    </div>
 </div>
 <div>
    <button type="submit" class="btn btn-primary">Guardar Cambios</button> 
    <a class="btn btn-primary" href="<?php echo e(route('asignatura')); ?>">Volver</a>
</div>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projectPHP\resources\views/editarasignatura.blade.php ENDPATH**/ ?>