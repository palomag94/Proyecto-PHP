<?php $__env->startSection('seccion'); ?>

<h3>Eliminación del Alumno</h3>

<form  action="<?php echo e(route('eliminaralumno','$id')); ?>" class="d-inline" method="POST">
        <?php echo csrf_field(); ?>
        <div>
            <p>¿Desea eliminar el alumno?</p>
        </div>
        <div >
             <button type="submit" class="btn btn-primary">Aceptar</button>
             <a class="btn btn-primary " href="<?php echo e(route ('alumno')); ?>" role="button">Cancelar</a>
        </div>
    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projectPHP\resources\views/eliminaralumno.blade.php ENDPATH**/ ?>