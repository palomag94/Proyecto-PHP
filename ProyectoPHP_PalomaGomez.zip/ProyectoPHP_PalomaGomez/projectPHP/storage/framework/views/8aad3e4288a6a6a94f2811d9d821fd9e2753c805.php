<?php $__env->startSection('seccion'); ?>

<form action="<?php echo e(route('buscaralumno')); ?>" class="form-inline my-2 my-lg-0">
  
      <input class="form-control mr-sm-2" type="text" placeholder="Nombre del alumno" aria-label="Buscar">
      <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Buscar</button>
</form>

<br> 

<h3>Datos de los alumnos</h3>

<br>

<table class="table">
  <thead class="thead-dark">
    <tr>
      <th scope="col">ID</th>
      <th scope="col">Nombre</th>
      <th scope="col">Apellidos</th>
      <th scope="col">DNI</th>
      <th scope="col">Direccion</th>
      <th scope="col">Email</th>
      <th scope="col">Fecha Nacimiento</th>
      <th scope="col">Poblacion</th>
      <th scope="col">Provincia</th>
      <th scope="col">Teléfono/s</th>
      <th scope="col">Acciones</th>
    </tr>
  </thead>

  <tbody>
      <?php $__currentLoopData = $alumno; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
        <th scope="row"><?php echo e($item->id); ?></th>
        <td><?php echo e($item->nombre); ?></td>
        <td><?php echo e($item->apellidos); ?></td>
        <td><?php echo e($item->DNI); ?></td>
        <td><?php echo e($item->direccion); ?></td>
        <td><?php echo e($item->email); ?></td>
        <td><?php echo e($item->fechaNacimiento); ?></td>
        <td><?php echo e($item->poblacion); ?></td>
        <td><?php echo e($item->provincia); ?></td>
        <td><?php echo e($item->Telefono); ?></td>

        <td> 
            <a  href="<?php echo e(route('editaralumno',$item)); ?>" >Editar</a>        

            <a  href="<?php echo e(route('eliminaralumno',$item)); ?>" >Eliminar</a>

        </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>

<p> <a class="btn btn-primary " href="<?php echo e(route ('crearalumno')); ?>" role="button">Crear Alumno</a>  <a class="btn btn-primary" href='/'>Volver</a></p>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projectPHP\resources\views/buscaralumno.blade.php ENDPATH**/ ?>