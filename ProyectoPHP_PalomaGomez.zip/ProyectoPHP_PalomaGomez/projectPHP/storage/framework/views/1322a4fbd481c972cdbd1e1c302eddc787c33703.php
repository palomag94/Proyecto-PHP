<?php $__env->startSection('seccion'); ?>

<h3>Nuevo Asignatura</h3>

<hr />

<?php if(session('mensaje')): ?>
    <div class="alert alert-success">
        <?php echo e(session('mensaje')); ?>

</div>
<?php endif; ?>

<form method="POST" action="<?php echo e(route('crearasignatura')); ?>">
<?php echo csrf_field(); ?>
  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="nombre">Nombre</label>
      <input type="text" class="form-control" id="nombre" name="nombre" placeholder="Nombre" required>
    </div>
 </div>
  <!--<div class="form-group">
    <div class="form-check">
      <input class="form-check-input" type="checkbox" id="gridCheck">
      <label class="form-check-label" for="gridCheck">
        Check me out
      </label>
    </div>
  </div>-->
  <button type="submit" class="btn btn-primary">Añadir</button> <a class="btn btn-primary" href="<?php echo e(route('asignatura')); ?>">Volver</a>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projectPHP\resources\views/crearasignatura.blade.php ENDPATH**/ ?>