<?php $__env->startSection('seccion'); ?>

<h3>Insertar Nota</h3>

<hr />

<?php if(session('mensaje')): ?>
    <div class="alert alert-success">
        <?php echo e(session('mensaje')); ?>

</div>
<?php endif; ?>

<form method="POST" action="<?php echo e(route('crearnota')); ?>">
<?php echo csrf_field(); ?>
  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="nombreAsignatura">Nombre Asignatura</label>
      <input type="text" class="form-control" id="nombreAsignatura" name="nombreAsignatura" placeholder="Nombre Asignatura" required>
    </div>
    <div class="form-group col-md-6">
      <label for="nombreAlumno">Nombre Alumno</label>
      <input type="text" class="form-control" id="nombreAlumno" name="nombreAlumno" placeholder="Nombre Alumno" required>
    </div>
    <div class="form-group col-md-6">
      <label for="valor">Valor</label>
      <input type="integer" class="form-control" id="valor" name="valor" placeholder="Valor" required>
    </div>
 </div>

  <button type="submit" class="btn btn-primary">Insertar</button> <a class="btn btn-primary" href="<?php echo e(route('nota')); ?>">Volver</a>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projectPHP\resources\views/crearnota.blade.php ENDPATH**/ ?>