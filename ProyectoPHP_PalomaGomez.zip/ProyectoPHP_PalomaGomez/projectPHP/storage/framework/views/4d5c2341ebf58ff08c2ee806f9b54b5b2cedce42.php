<?php $__env->startSection('seccion'); ?>

<h3>Editar Alumno</h3>

<hr />

<form action="<?php echo e(route('editaralumno',$alumno->id)); ?>" class="d-inline" method="POST">
<?php echo method_field('PUT'); ?>
<?php echo csrf_field(); ?>

<div class="form-row">
    <div class="form-group col-md-6">
      <label for="nombre">Nombre</label>
      <input type="text" class="form-control" id="nombre" name ="nombre" placeholder="Nombre"   value="<?php echo e($alumno->nombre); ?>">
    </div>
    <div class="form-group col-md-6">
      <label for="apellidos">Apellidos</label>
      <input type="text" class="form-control" id="apellidos"  name="apellidos" placeholder="Apellidos" value="<?php echo e($alumno->apellidos); ?>">
    </div>
  </div>

  <div class="form-row">
    <div class="form-group col-md-6">
        <label for="dni">DNI</label>
        <input type="text" class="form-control" id="dni"  name="dni" placeholder="DNI" value="<?php echo e($alumno->DNI); ?>">
    </div>
    <div class="form-group col-md-6">
      <label for="fechanacimiento">Fecha Nacimiento</label>
      <input type="date" class="form-control" id="fechanacimiento"  name="fechanacimiento" placeholder="Fecha Nacimiento" value="<?php echo e($alumno->fechaNacimiento); ?>">
    </div>
  </div>

  <div class="form-group">
    <label for="direccion">Dirección</label>
    <input type="text" class="form-control" id="direccion" name="direccion" placeholder="Dirección" value="<?php echo e($alumno->direccion); ?>">
  </div>
  <div class="form-group">
    <label for="email">Email</label>
    <input type="text" class="form-control" id="email" name="email" placeholder="Email" value="<?php echo e($alumno->email); ?>">
  </div>
  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="poblacion">Población</label>
      <input type="text" class="form-control" id="poblacion" name="poblacion" placeholder="Población" value="<?php echo e($alumno->poblacion); ?>">
    </div>
    <div class="form-group col-md-6">
      <label for="provincia">Provincia</label>
      <select id="provincia" name="provincia" class="form-control">
        <option selected>Elige Provincia</option>
        <option value='alava'>Álava</option>
        <option value='albacete'>Albacete</option>
        <option value='alicante'>Alicante/Alacant</option>
        <option value='almeria'>Almería</option>
        <option value='asturias'>Asturias</option>
        <option value='avila'>Ávila</option>
        <option value='badajoz'>Badajoz</option>
        <option value='barcelona'>Barcelona</option>
        <option value='burgos'>Burgos</option>
        <option value='caceres'>Cáceres</option>
        <option value='cadiz'>Cádiz</option>
        <option value='cantabria'>Cantabria</option>
        <option value='castellon'>Castellón/Castelló</option>
        <option value='ceuta'>Ceuta</option>
        <option value='ciudadreal'>Ciudad Real</option>
        <option value='cordoba'>Córdoba</option>
        <option value='cuenca'>Cuenca</option>
        <option value='girona'>Girona</option>
        <option value='laspalmas'>Las Palmas</option>
        <option value='granada'>Granada</option>
        <option value='guadalajara'>Guadalajara</option>
        <option value='guipuzcoa'>Guipúzcoa</option>
        <option value='huelva'>Huelva</option>
        <option value='huesca'>Huesca</option>
        <option value='illesbalears'>Illes Balears</option>
        <option value='jaen'>Jaén</option>
        <option value='acoruña'>A Coruña</option>
        <option value='larioja'>La Rioja</option>
        <option value='leon'>León</option>
        <option value='lleida'>Lleida</option>
        <option value='lugo'>Lugo</option>
        <option value='madrid'>Madrid</option>
        <option value='malaga'>Málaga</option>
        <option value='melilla'>Melilla</option>
        <option value='murcia'>Murcia</option>
        <option value='navarra'>Navarra</option>
        <option value='ourense'>Ourense</option>
        <option value='palencia'>Palencia</option>
        <option value='pontevedra'>Pontevedra</option>
        <option value='salamanca'>Salamanca</option>
        <option value='segovia'>Segovia</option>
        <option value='sevilla'>Sevilla</option>
        <option value='soria'>Soria</option>
        <option value='tarragona'>Tarragona</option>
        <option value='santacruztenerife'>Santa Cruz de Tenerife</option>
        <option value='teruel'>Teruel</option>
        <option value='toledo'>Toledo</option>
        <option value='valencia'>Valencia/Valéncia</option>
        <option value='valladolid'>Valladolid</option>
        <option value='vizcaya'>Vizcaya</option>
        <option value='zamora'>Zamora</option>
        <option value='zaragoza'>Zaragoza</option>
      </select>
    </div>
  </div>

  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="telefono">Telefono</label>
      <input type="number" class="form-control" id="telefono" name="telefono" placeholder="Telefono" value="<?php echo e($alumno->Telefono); ?>">
    </div>
 </div>

<div>
  <button type="submit" class="btn btn-primary">Guardar Cambios</button>
  <a class="btn btn-primary" href="<?php echo e(route ('alumno')); ?>" role="button">Volver</a>
</div>

</form>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projectPHP\resources\views/editaralumno.blade.php ENDPATH**/ ?>