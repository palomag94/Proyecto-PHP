<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Alumnos extends Model
{
    //
    private $pdo;

    protected $table = 'alumno';
    
    public function telephones(){
        return $this->hasMany('App\Telefono');
    }


    public function subjects(){
        return $this->belongsToMany('App\Asignaturas');
    }
}
