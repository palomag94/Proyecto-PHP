<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Asignaturas extends Model
{
    //
    protected $table = 'asignatura';

    public function subjects(){
        return $this->belongsToMany('App\Alumnos');
    }
}
