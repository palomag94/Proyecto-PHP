<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App;
use App\Alumnos;
use DB;

class PageController extends Controller
{
    //INICIO

    public function inicio(){
        $notas=array();
        return view('home',compact('notas'));

    }

    public function resumenNotas(){      
        $sql="select A.nombre, A.Apellidos, B.nombre as asignatura, AVG(N.valor) as Nota FROM `Alumno` as A Inner Join `Nota` 
        as N on A.nombre=N.nombreAlumno inner join `asignatura` as B on B.nombre=N.nombreAsignatura group by A.nombre,A.apellidos, asignatura asc";

        $notas=DB::connection('mysql')->select(DB::raw($sql));

        return view('home',compact('notas'));
    }


    ///ALUMNOS
    public function alumno(){
        $alumno = App\Alumnos::all();
        return view('alumno',compact('alumno'));
    }

    public function ShowViewCrearAlumno(){
        return view('crearalumno');
    }

    public function crearalumno(Request $request){
        $alumnoNuevo = new App\Alumnos;
        $alumnoNuevo->nombre=$request->nombre;
        $alumnoNuevo->apellidos=$request->apellidos;
        $alumnoNuevo->dni=$request->dni;
        $alumnoNuevo->direccion=$request->direccion;
        $alumnoNuevo->email=$request->email;
        $alumnoNuevo->poblacion=$request->poblacion;
        $alumnoNuevo->provincia=$request->provincia;
        $alumnoNuevo->fechanacimiento=$request->fechanacimiento;
        $alumnoNuevo->telefono=$request->telefono;
        
        $alumnoNuevo->save();

        return back()->with('mensaje', 'Alumno Creado');
    }

    public function ShowVieweditaralumno($id){

        $alumno = App\Alumnos::findOrFail($id); 
        return view('editaralumno', compact('alumno'));

    }

    public function editaralumno(Request $request,$id){

        $alumnoUpdate = Alumnos::findOrFail($id); 

        $alumnoUpdate->nombre=$request->nombre;
        $alumnoUpdate->apellidos=$request->apellidos;
        $alumnoUpdate->dni=$request->dni;
        $alumnoUpdate->direccion=$request->direccion;
        $alumnoUpdate->email=$request->email;
        $alumnoUpdate->poblacion=$request->poblacion;
        $alumnoUpdate->provincia=$request->provincia;
        $alumnoUpdate->fechanacimiento=$request->fechanacimiento;
        $alumnoUpdate->telefono=$request->telefono;
        

        $alumnoUpdate->save();

        return back()->with('mensaje', 'Alumno Actualizado');   
    }

    public function eliminaralumno($id) {
        $alumno=App\Alumnos::findOrFail($id);      
        $alumno->delete();
        return back()->with('mensaje', 'Alumno Eliminado');   
     }


     public function buscaralumno(Request $request){
       
       $alumno=null;
        if($request->nombre!=null)
        {
            $alumno = App\Alumnos::select()
            ->where('nombre', 'LIKE', '%'.$request->nombre.'%')
            ->get();
        }
        else
        {
            $alumno = App\Alumnos::all();
            return view('alumno',compact('alumno'));
        }
            
        
        return view('alumno', compact('alumno'));
     }



     ///ASIGNATURAS
    public function asignatura(){
        $asignatura = App\Asignaturas::all();
        return view('asignatura',compact('asignatura'));
    }

    public function crearasignatura(Request $request){

        $asignaturaNueva = new App\Asignaturas;
        $asignaturaNueva->nombre=$request->nombre;

        $asignaturaNueva->save();

        return back()->with('mensaje', 'Asignatura Creada');
    }

    public function ShowViewCrearAsignatura(){
        return view('crearasignatura');
    }

    public function eliminarasignatura($id) {
        $asignatura=App\Asignaturas::findOrFail($id);      
        $asignatura->delete();
        return back()->with('mensaje', 'Asignatura Eliminada');   
     }

     public function ShowVieweditarasignatura($id){

        $asignatura = App\Asignaturas::findOrFail($id); 
        return view('editarasignatura', compact('asignatura'));

    }

    public function editarasignatura(Request $request,$id){

        $asignaturaUpdate = App\Asignaturas::findOrFail($id); 

        $asignaturaUpdate->nombre=$request->nombre;

        $asignaturaUpdate->save();

        return back()->with('mensaje', 'Asignatura Actualizada');   
    }
    

    ///NOTAS
    public function nota(){
        $nota = App\Nota::all();
        return view('nota',compact('nota'));
    }

    public function ShowViewCrearNota(){
        return view('crearnota');
    }
    
    public function crearnota(Request $request){

        $notaNueva = new App\Nota;
        
        $notaNueva->nombreAsignatura=$request->nombreAsignatura;
        $notaNueva->nombreAlumno=$request->nombreAlumno;
        $notaNueva->valor=$request->valor;

        $notaNueva->save();

        return back()->with('mensaje', 'Nota Añadida');
    }

}
